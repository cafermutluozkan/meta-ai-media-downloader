// Popup script - mevcut sekmeyi kontrol et
const dot = document.getElementById('statusDot');
const title = document.getElementById('statusTitle');
const msg = document.getElementById('statusMsg');

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  if (!tab) return;

  const url = tab.url || '';

  if (url.includes('meta.ai')) {
    dot.classList.add('active');
    title.textContent = 'Aktif ✓';
    msg.textContent = 'Meta AI sayfası algılandı';
  } else {
    dot.classList.remove('active');
    title.textContent = 'Devre dışı';
    msg.textContent = 'meta.ai sayfasına git';
  }
});
