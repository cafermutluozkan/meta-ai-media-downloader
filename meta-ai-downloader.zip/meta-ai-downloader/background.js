// Meta AI Video Downloader - Background Service Worker
// chrome.downloads API kullanarak cross-origin video indirir

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'downloadVideo') {
    handleDownload(message.url, message.filename, sendResponse);
    return true; // async response için gerekli
  }
});

async function handleDownload(url, filename, sendResponse) {
  try {
    // chrome.downloads.download direkt URL'den indirir (CORS sorunu yok)
    chrome.downloads.download(
      {
        url: url,
        filename: filename || 'meta-ai-video.mp4',
        saveAs: false, // Direkt indir, dialog açma
        conflictAction: 'uniquify' // Aynı isimde dosya varsa _1, _2 ekle
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          console.error('[MetaAI DL] İndirme hatası:', chrome.runtime.lastError.message);
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          console.log('[MetaAI DL] İndirme başladı, ID:', downloadId);
          sendResponse({ success: true, downloadId });
        }
      }
    );
  } catch (err) {
    console.error('[MetaAI DL] Beklenmeyen hata:', err);
    sendResponse({ success: false, error: err.message });
  }
}
