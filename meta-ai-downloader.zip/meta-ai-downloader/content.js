// Meta AI Video Downloader - Content Script
// Sayfadaki video elementlerini izler ve indirme butonu ekler

const BUTTON_CLASS = 'metaai-dl-btn';
const PROCESSED_ATTR = 'data-metaai-processed';

// ─── Buton oluştur ───────────────────────────────────────────────────────────
function createDownloadButton(videoUrl, filename) {
  const btn = document.createElement('button');
  btn.className = BUTTON_CLASS;
  btn.title = 'Fligransız İndir';
  btn.setAttribute('aria-label', 'Fligransız İndir');
  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7 10 12 15 17 10"/>
      <line x1="12" y1="15" x2="12" y2="3"/>
    </svg>
    <span>İndir</span>
  `;

  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    startDownload(videoUrl, filename, btn);
  });

  return btn;
}

// ─── İndirmeyi başlat ────────────────────────────────────────────────────────
function startDownload(url, filename, btn) {
  // Buton durumunu güncelle
  btn.classList.add('loading');
  btn.innerHTML = `
    <svg class="spin" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </svg>
    <span>İndiriliyor...</span>
  `;

  // Background service worker'a mesaj gönder
  chrome.runtime.sendMessage(
    { action: 'downloadVideo', url, filename },
    (response) => {
      if (response?.success) {
        btn.classList.remove('loading');
        btn.classList.add('success');
        btn.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Tamamlandı!</span>
        `;
        setTimeout(() => resetButton(btn, url, filename), 2500);
      } else {
        btn.classList.remove('loading');
        btn.classList.add('error');
        btn.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <span>Hata! Tekrar dene</span>
        `;
        setTimeout(() => resetButton(btn, url, filename), 2500);
      }
    }
  );
}

function resetButton(btn, url, filename) {
  btn.classList.remove('success', 'error', 'loading');
  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7 10 12 15 17 10"/>
      <line x1="12" y1="15" x2="12" y2="3"/>
    </svg>
    <span>İndir</span>
  `;
}

// ─── Video URL'sini al ────────────────────────────────────────────────────────
function getVideoUrl(videoEl) {
  // 1. src attribute
  let url = videoEl.getAttribute('src') || videoEl.src;

  // 2. source elementleri dene
  if (!url || url.startsWith('blob:')) {
    const source = videoEl.querySelector('source[src]');
    if (source) url = source.getAttribute('src');
  }

  // 3. currentSrc (tarayıcının seçtiği kaynak)
  if (!url || url.startsWith('blob:')) {
    url = videoEl.currentSrc;
  }

  // Geçerli fbcdn veya meta CDN URL'si mi?
  if (url && !url.startsWith('blob:') && (url.includes('fbcdn.net') || url.includes('cdninstagram.com') || url.includes('meta.ai'))) {
    return url;
  }

  return null;
}

// ─── Dosya adı üret ──────────────────────────────────────────────────────────
function generateFilename(url) {
  const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  return `meta-ai-video-${timestamp}.mp4`;
}

// ─── Video elementi işle ──────────────────────────────────────────────────────
function processVideo(videoEl) {
  if (videoEl.hasAttribute(PROCESSED_ATTR)) return;
  videoEl.setAttribute(PROCESSED_ATTR, 'true');

  // Container bul veya oluştur
  const container = videoEl.closest('.group') || videoEl.parentElement;
  if (!container) return;

  // Container'ı relative yap (buton konumlandırması için)
  const style = window.getComputedStyle(container);
  if (style.position === 'static') {
    container.style.position = 'relative';
  }

  // URL al - bazen video henüz yüklenmemiş olabilir
  const tryInject = () => {
    const url = getVideoUrl(videoEl);
    if (!url) {
      // Kısa bekle ve tekrar dene
      setTimeout(tryInject, 500);
      return;
    }

    const filename = generateFilename(url);
    const btn = createDownloadButton(url, filename);
    container.appendChild(btn);
  };

  // Video yüklüyse hemen, değilse event bekle
  if (videoEl.readyState >= 1 || videoEl.src) {
    tryInject();
  } else {
    videoEl.addEventListener('loadedmetadata', tryInject, { once: true });
    videoEl.addEventListener('canplay', tryInject, { once: true });
    // Fallback: 1 saniye sonra dene
    setTimeout(tryInject, 1000);
  }
}

// ─── Tüm videoları tara ───────────────────────────────────────────────────────
function scanForVideos() {
  document.querySelectorAll(`video:not([${PROCESSED_ATTR}])`).forEach(processVideo);
}

// ─── MutationObserver: SPA için dinamik içerik izle ──────────────────────────
const observer = new MutationObserver((mutations) => {
  let shouldScan = false;
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName === 'VIDEO' || node.querySelector?.('video')) {
          shouldScan = true;
          break;
        }
      }
    }
    if (shouldScan) break;
  }
  if (shouldScan) scanForVideos();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// İlk tarama
scanForVideos();
